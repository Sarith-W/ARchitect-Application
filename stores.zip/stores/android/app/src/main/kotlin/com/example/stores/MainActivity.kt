package com.example.stores

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
