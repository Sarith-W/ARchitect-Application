import 'package:flutter/material.dart';

class Product extends StatefulWidget {
  const Product({super.key});

  @override
  State<Product> createState() => _ProductState();
}

class _ProductState extends State<Product> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        leading: IconButton(
          icon: const Icon(Icons.home),
          onPressed: () {
            // Navigate wenna oni route eka daganin
          },
        ),
        centerTitle: true,
        title: const Image(
          // alignment: Alignment.center,
          image: AssetImage('assests/logo.PNG'),
          height: 40,
          width: 70,
        ),
        actions: <Widget>[
          IconButton(
            icon: const Icon(Icons.shopping_cart),
            onPressed: () {
              // Navigate wenna oni route eka daganin
            },
          ),
        ],
      ),
      body: SingleChildScrollView(
        child: Center(
          child: Column(
            children: [
              const SizedBox(
                height: 30,
              ),
              const Text(
                "Customize the Product",
                style: TextStyle(fontWeight: FontWeight.bold, fontSize: 24),
              ),
      
              const Image(
                image: AssetImage('assests/sofa.jpeg'),
                height: 350,
                // width: 70,
              ),
      
              // const SizedBox(height: 10,),
              const Text(
                "Select a color",
                style: TextStyle(fontSize: 20),
              ),
      
              const SizedBox(
                height: 10,
              ),
      
              Center(
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Container(
                      width: 20,
                      height: 20,
                      decoration: const BoxDecoration(
                        shape: BoxShape.circle,
                        color: Colors.green,
                      ),
                    ),
                    const SizedBox(
                      width: 15,
                    ),
                    Container(
                      width: 20,
                      height: 20,
                      decoration: const BoxDecoration(
                        shape: BoxShape.circle,
                        color: Colors.red,
                      ),
                    ),
                    const SizedBox(
                      width: 15,
                    ),
                    Container(
                      width: 20,
                      height: 20,
                      decoration: const BoxDecoration(
                        shape: BoxShape.circle,
                        color: Colors.blue,
                      ),
                    ),
                    const SizedBox(
                      width: 15,
                    ),
                    Container(
                      width: 20,
                      height: 20,
                      decoration: const BoxDecoration(
                        shape: BoxShape.circle,
                        color: Colors.yellow,
                      ),
                    ),
                  ],
                ),
              ),
      
              const SizedBox(
                height: 15,
              ),
              const Text(
                "Select a dimention",
                style: TextStyle(fontSize: 20),
              ),
      
              Center(
                child: Padding(
                  padding: const EdgeInsets.only(left: 20, right: 20),
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: const [
                      // ElevatedButton(onPressed: (){}, child: const Text("Length")),
                      // const SizedBox(width: 10,),
      
                      // ElevatedButton(onPressed: (){}, child: const Text("Width")),
                      // const SizedBox(width: 10,),
      
                      // ElevatedButton(onPressed: (){}, child: const Text("Hight")),
                      // const SizedBox(width: 10,),
      
                      Expanded(
                        child: TextField(
                          keyboardType: TextInputType.number,
                          decoration: InputDecoration(
                            labelText: 'Length',
                            border: UnderlineInputBorder(),
                          ),
                        ),
                      ),
                      SizedBox(width: 16.0),
                      Expanded(
                        child: TextField(
                          keyboardType: TextInputType.number,
                          decoration: InputDecoration(
                            labelText: 'Width',
                            border: UnderlineInputBorder(),
                          ),
                        ),
                      ),
                      SizedBox(width: 16.0),
                      Expanded(
                        child: TextField(
                          keyboardType: TextInputType.number,
                          decoration: InputDecoration(
                            labelText: 'Height',
                            border: UnderlineInputBorder(),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
      
              const SizedBox(
                height: 15,
              ),
              ElevatedButton(
                  // style: ElevatedButton.styleFrom(
                  //   backgroundColor: Colors.black, // Background color
                  // ),
                  onPressed: () {},
                  child: const Text("View In AR"))
            ],
          ),
        ),
      ),
    );
  }
}
